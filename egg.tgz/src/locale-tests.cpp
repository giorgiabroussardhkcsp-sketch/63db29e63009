// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("locale tests"); }
int main(){
  announce();
  return lionss_run_workload("locale-tests");
}
