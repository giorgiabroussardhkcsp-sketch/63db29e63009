// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("reproducible build"); }
int main(){
  announce();
  return lionss_run_workload("reproducible-build");
}
