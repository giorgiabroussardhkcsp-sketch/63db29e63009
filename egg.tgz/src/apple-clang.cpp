// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("apple clang"); }
int main(){
  announce();
  return lionss_run_workload("apple-clang");
}
