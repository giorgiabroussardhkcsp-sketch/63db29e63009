// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lsan"); }
int main(){
  announce();
  return lionss_run_workload("lsan");
}
